import { useState } from 'react';
import {
  ArrowDownRight,
  ArrowRight,
  ArrowUpRight,
  BatteryCharging,
  Check,
  CircuitBoard,
  Copy,
  FileText,
  GitBranch,
  Menu,
  Radio,
  RotateCcw,
  Timer,
  Waves,
  X,
} from 'lucide-react';

const sections = [
  ['System', '#system'],
  ['Physics', '#physics'],
  ['Experiments', '#experiments'],
  ['Roadmap', '#roadmap'],
  ['Paper + demo', '#publication'],
];

const trials = [
  { id: 'gap', number: '01', name: 'Air-gap sweep', variable: 'coil separation', range: '10 → 50 mm', response: 'Received voltage / coupling', color: 'teal' },
  { id: 'offset', number: '02', name: 'Lateral offset', variable: 'receiver alignment', range: '0 → 40 mm', response: 'Power vs. displacement', color: 'orange' },
  { id: 'thermal', number: '03', name: 'Thermal rise', variable: 'continuous run time', range: '0 → 20 min', response: 'Coil temperature ΔT', color: 'gold' },
  { id: 'vibration', number: '04', name: 'Vibration yield', variable: 'excitation frequency', range: '5 → 30 Hz', response: 'Rectified energy / time', color: 'blue' },
];

const roadmap = [
  { step: '01', phase: 'Scope', status: 'IN PROGRESS', title: 'Separate the class brief from the research.', body: 'Record the school rubric, then define the independent work: sensor-gated segment switching, LC tuning, and a bench-scale test plan. Keep each added feature tied to a question that can be measured.' },
  { step: '02', phase: 'Bench', status: 'NEXT', title: 'Establish a clean baseline.', body: 'Build a low-voltage resonant link, instrument both sides, and characterize coupling across air gap and lateral misalignment. Keep a fixed reference condition for every session.' },
  { step: '03', phase: 'Stress', status: 'PLANNED', title: 'Probe what changes the result.', body: 'Repeat trials under controlled offset, temperature, and vibration conditions. Log uncertainty, repeatability, and thermal behavior—not just the best run.' },
  { step: '04', phase: 'Integrate', status: 'PLANNED', title: 'Add an independent energy path.', body: 'Test a small vibration harvester as an auxiliary source for sensing and control. Compare rectification, storage, and load behavior against a no-harvester baseline.' },
  { step: '05', phase: 'Publish', status: 'PLANNED', title: 'Release the work, including misses.', body: 'Publish KiCad schematics, code, bill of materials, raw CSVs, and analysis notebooks. Prepare a 4–6 page IEEE-style paper and a 60-second demo with live telemetry; label every result by its evidence status.' },
];

function SectionHeading({ kicker, title, detail }: { kicker: string; title: string; detail?: string }) {
  return (
    <div className="section-heading">
      <p className="eyebrow">{kicker}</p>
      <div className="heading-row">
        <h2 className="display">{title}</h2>
        {detail && <p className="heading-detail">{detail}</p>}
      </div>
    </div>
  );
}

function CoilGraphic() {
  return (
    <div className="system-graphic" role="img" aria-label="Conceptual cross-section showing road transmitter coil, air gap, receiver coil, and auxiliary vibration harvester.">
      <div className="graphic-topline"><span>CONCEPTUAL CROSS-SECTION</span><span>NOT TO SCALE</span></div>
      <svg viewBox="0 0 760 355" className="coil-svg" aria-hidden="true">
        <defs>
          <pattern id="road-grid" width="22" height="22" patternUnits="userSpaceOnUse">
            <path d="M22 0H0V22" fill="none" stroke="#d7d4c8" strokeWidth="1" />
          </pattern>
          <linearGradient id="road-fill" x1="0" x2="0" y1="0" y2="1">
            <stop offset="0" stopColor="#e7e3d7" />
            <stop offset="1" stopColor="#d4d0c4" />
          </linearGradient>
          <marker id="arrow" markerWidth="7" markerHeight="7" refX="5" refY="3.5" orient="auto">
            <path d="M0 0L7 3.5L0 7" fill="none" stroke="#e27a45" strokeWidth="1.4" />
          </marker>
        </defs>
        <rect x="30" y="31" width="700" height="148" rx="2" fill="#f6f4ed" stroke="#d9d5c9" />
        <path d="M30 155H730" stroke="#c9c6ba" strokeDasharray="5 8" />
        <path d="M30 95H730" stroke="#ddd9ce" strokeDasharray="2 8" />
        <text x="54" y="59" className="svg-label">VEHICLE UNDERBODY</text>
        <rect x="125" y="76" width="495" height="55" rx="9" fill="#dbe5dc" stroke="#4b756c" strokeWidth="1.4" />
        <path d="M160 108h80m25 0h85m25 0h85m25 0h85" stroke="#4b756c" strokeWidth="2" />
        <text x="275" y="99" className="svg-small">RECEIVER + COMPENSATION</text>
        <path d="M340 132V205" stroke="#e27a45" strokeWidth="1.3" strokeDasharray="4 5" markerEnd="url(#arrow)" />
        <path d="M405 132V205" stroke="#e27a45" strokeWidth="1.3" strokeDasharray="4 5" markerEnd="url(#arrow)" />
        <path d="M348 169H397" stroke="#e27a45" strokeWidth="1" markerStart="url(#arrow)" markerEnd="url(#arrow)" />
        <text x="359" y="162" className="svg-small svg-orange">AIR GAP</text>
        <rect x="30" y="207" width="700" height="110" fill="url(#road-fill)" stroke="#c9c4b5" />
        <rect x="30" y="207" width="700" height="110" fill="url(#road-grid)" opacity=".48" />
        <text x="54" y="237" className="svg-label">ROAD-SURFACE MODULE</text>
        <path d="M289 258c0-24 16-24 16 0s16 24 16 0 16-24 16 0 16 24 16 0 16-24 16 0" fill="none" stroke="#17665b" strokeWidth="3" />
        <path d="M288 286h81" stroke="#17665b" strokeWidth="1" />
        <text x="286" y="305" className="svg-small">SWITCHED TX COIL</text>
        <rect x="492" y="252" width="97" height="35" rx="4" fill="#f5e0d1" stroke="#cb7547" />
        <path d="M506 269h12l8-9 11 18 8-9h31" fill="none" stroke="#bd6439" strokeWidth="1.7" />
        <text x="488" y="305" className="svg-small">VIBRATION HARVESTER</text>
        <path d="M415 268h46" stroke="#e27a45" strokeWidth="1.3" markerEnd="url(#arrow)" />
        <text x="411" y="254" className="svg-small svg-orange">AUXILIARY PATH</text>
        <text x="57" y="283" className="svg-tiny">SUBGRADE</text>
      </svg>
      <div className="graphic-caption"><span><i className="legend-dot legend-teal" /> Inductive power path</span><span><i className="legend-dot legend-orange" /> Auxiliary sensing path</span><span>Concept only · no hardware depicted</span></div>
    </div>
  );
}

function App() {
  const [menuOpen, setMenuOpen] = useState(false);
  const [activeTrial, setActiveTrial] = useState('gap');
  const [copied, setCopied] = useState(false);
  const selectedTrial = trials.find((trial) => trial.id === activeTrial) ?? trials[0];
  const activity = 'Lead Independent Researcher — Autonomous Hybrid Highway Infrastructure (AHHI). Developing a bench-scale research plan for dynamic inductive EV charging and low-power road vibration harvesting. Planned work includes sensor-gated coil segments, LC resonance tuning, and repeatable tests for air-gap coupling, lateral misalignment, thermal rise, and vibration yield. Intended outputs include open-source KiCad schematics, code, raw data, an IEEE-style paper, and a short live-telemetry demo. No experimental results or completed prototype are claimed yet.';

  async function copyActivity() {
    try {
      await navigator.clipboard.writeText(activity);
      setCopied(true);
      window.setTimeout(() => setCopied(false), 2200);
    } catch {
      setCopied(false);
    }
  }

  return (
    <div className="site-shell noise">
      <a className="skip-link" href="#main">Skip to content</a>
      <header className="site-header">
        <a className="wordmark focus-ring" href="#top" aria-label="AHHI Research Portfolio home">
          <span className="mark">A<span>H</span></span>
          <span className="brand-copy"><b>AHHI</b><small>RESEARCH PORTFOLIO</small></span>
        </a>
        <nav className={`nav ${menuOpen ? 'nav-open' : ''}`} aria-label="Main navigation">
          {sections.map(([label, href]) => <a key={href} className="nav-link focus-ring" href={href} onClick={() => setMenuOpen(false)}>{label}</a>)}
          <a className="nav-cta focus-ring" href="#proof" onClick={() => setMenuOpen(false)}>Open notebook <ArrowUpRight size={14} /></a>
        </nav>
        <button className="mobile-menu focus-ring" type="button" aria-label={menuOpen ? 'Close navigation' : 'Open navigation'} aria-expanded={menuOpen} onClick={() => setMenuOpen(!menuOpen)} data-testid="button-menu">
          {menuOpen ? <X size={20} /> : <Menu size={20} />}
        </button>
      </header>

      <main id="main">
        <section className="hero wrap" id="top">
          <div className="hero-left">
            <div className="hero-meta reveal"><span className="live-dot" /> INDEPENDENT ENGINEERING RESEARCH <span className="meta-line" /> CONCEPT → TESTABLE SYSTEM</div>
            <h1 className="display reveal delay-1">Energy in the road.<br /><em>Questions</em> in the open.</h1>
            <p className="hero-deck reveal delay-2">A student-led investigation into whether dynamic wireless charging and modest road-energy harvesting can share a highway prototype—and what careful measurement would have to prove first.</p>
            <div className="hero-actions reveal delay-3">
              <a className="button-primary focus-ring" href="#system">Explore the system <ArrowDownRight size={16} /></a>
              <a className="text-link focus-ring" href="#experiments">Read the test plan <ArrowRight size={15} /></a>
            </div>
            <div className="hero-footnote reveal delay-3"><span className="mono">RESEARCH STATUS</span><span className="status-pill"><i /> PRE-EXPERIMENTAL</span><span>Concept and plan only. No measured results yet.</span></div>
          </div>
          <div className="hero-art reveal delay-2" aria-label="Illustration of a vehicle over a conceptual inductive road coil">
            <div className="art-label art-label-top"><span className="mono">01 / SYSTEM IDEA</span><span>HIGHWAY CROSS-SECTION</span></div>
            <div className="road-scene">
              <div className="scene-sky">
                <div className="road-sun" />
                <div className="horizon h1" /><div className="horizon h2" />
                <div className="vehicle">
                  <div className="car-window" /><div className="car-body" /><div className="car-wheel wheel-a" /><div className="car-wheel wheel-b" />
                  <div className="car-line" />
                </div>
                <div className="field-lines"><i /><i /><i /><i /><i /></div>
                <div className="motion-dashes"><i /><i /><i /></div>
              </div>
              <div className="road-top"><span className="road-mark" /><span className="road-mark" /><span className="road-mark" /></div>
              <div className="road-core"><div className="coil-art"><i /><i /><i /><i /><i /><i /><i /></div><div className="harvest-art"><b /><b /><b /></div><div className="road-label mono">EMBEDDED TX COIL</div></div>
              <div className="road-base"><span>ROAD AS INTERFACE</span><span className="mono">SCHEMATIC / NOT TO SCALE</span></div>
            </div>
            <div className="art-label art-label-bottom"><span><b>FIG. 01</b> Two energy paths. One measurement problem.</span><span className="mono">FIELD / 01</span></div>
            <div className="floating-callout"><span className="callout-icon"><Waves size={16} /></span><span><b>Inductive transfer</b><small>Primary research path</small></span><span className="callout-arrow">↗</span></div>
          </div>
        </section>

        <section className="truth-strip">
          <div className="wrap truth-inner">
            <div className="truth-mark"><span>!</span> EVIDENCE BOUNDARY</div>
            <p>This is a research plan, not a report of a finished prototype. Every graphic and chart marked <strong>illustrative</strong> is a design aid—not telemetry, measured performance, or proof of feasibility.</p>
            <a href="#integrity" className="truth-link focus-ring">How claims are handled <ArrowRight size={14} /></a>
          </div>
        </section>

        <section className="section wrap" id="system">
          <SectionHeading kicker="01 — The system" title="Two energy paths. Different jobs." detail="The project pairs a primary, actively driven inductive link with a separate, low-power vibration harvester. Their outputs are not interchangeable." />
          <div className="system-grid">
            <CoilGraphic />
            <div className="system-copy">
              <article className="system-card primary-card">
                <div className="card-icon"><Radio size={18} /></div>
                <div><span className="mono card-index">PATH A / PRIMARY</span><h3>Dynamic inductive transfer</h3><p>High-frequency AC in a road-side transmitter creates an oscillating magnetic field. A moving receiver captures flux across an air gap; the received AC is rectified to DC. Compensation networks may tune the link near resonance.</p></div>
              </article>
              <article className="system-card">
                <div className="card-icon orange-icon"><Waves size={18} /></div>
                <div><span className="mono card-index">PATH B / AUXILIARY</span><h3>Mechanical energy harvesting</h3><p>Road vibration could stress piezoelectric elements or move a spring-mounted magnet through a coil. After rectification and buffering, milliwatt-to-low-watt output may support sensors, controls, or indicators—not vehicle propulsion.</p></div>
              </article>
              <div className="systems-note"><span className="note-mark">↳</span><p><b>Not an energy multiplier.</b> The harvester is a supporting subsystem, with conversion losses of its own. Its value is a testable question, not an assumed benefit.</p></div>
            </div>
          </div>
        </section>

        <section className="physics-band" id="physics">
          <div className="wrap physics-wrap">
            <div className="physics-intro">
              <p className="eyebrow">02 — Working principles</p>
              <h2 className="display">The interesting part<br />is the <em>coupling.</em></h2>
              <p>Engineering lives in the constraints: alignment, switching losses, resonant tuning, thermal behavior, and the difference between a plausible diagram and a repeatable measurement.</p>
              <a className="light-link focus-ring" href="#experiments">See how it will be tested <ArrowRight size={15} /></a>
            </div>
            <div className="physics-content">
              <div className="formula-card">
                <div className="formula-head"><span className="mono">A USEFUL FIRST MODEL</span><span className="formula-tag">IDEALIZED</span></div>
                <div className="formula">M = k <span>√(L₁L₂)</span></div>
                <p>Mutual inductance depends on coil geometry and coupling coefficient <i>k</i>. As gap or offset changes, coupling generally changes too; it must be measured for this geometry.</p>
                <div className="formula-foot"><span>k ∈ [0, 1] in the ideal model</span><span>Not a performance prediction</span></div>
              </div>
              <div className="physics-points">
                <article><span className="point-no">A</span><div><h3>Switching creates the field</h3><p>A controlled inverter drives the transmitter coil with alternating current. Switching frequency and waveform are design variables with safety and loss trade-offs.</p></div></article>
                <article><span className="point-no">B</span><div><h3>Resonance may compensate</h3><p>Capacitors can tune inductive networks near resonance. A useful operating point depends on the actual coil, load, coupling, and circuit—nothing here assumes a universal optimum.</p></div></article>
                <article><span className="point-no">C</span><div><h3>Power has to be accounted for</h3><p>Log input and received-side quantities together. Include instrument limits, repeat runs, and temperature; otherwise an apparent gain can hide losses or drift.</p></div></article>
              </div>
              <div className="equation-grid" aria-label="Reference equations for the planned experiments">
                <article className="equation-note"><span className="mono">RESONANT FREQUENCY</span><strong>f₀ = 1 / (2π√LC)</strong><p>Choose and verify L and C for the measured coil and load; frequency matching is a tuning target, not a measured result.</p></article>
                <article className="equation-note"><span className="mono">INDUCED EMF</span><strong>ℰ = −N dΦ/dt</strong><p>Receiver voltage depends on turns and changing magnetic flux through the coil.</p></article>
                <article className="equation-note"><span className="mono">PIEZOELECTRIC MODEL</span><strong>Q ≈ dF</strong><p>A first-order relation between charge, force, and the material coefficient; real output also depends on geometry, loading, and losses.</p></article>
              </div>
              <div className="control-chain">
                <article><span className="mono">PLANNED SEGMENT CONTROL</span><p>An optical or magnetic vehicle sensor could signal a microcontroller such as an ESP32 to enable only the occupied transmitter segment. Switching, sensing, and interlocks remain design work to validate.</p></article>
                <article><span className="mono">AUXILIARY POWER PATH</span><p>Harvester output → bridge rectifier → capacitor or buffer → low-power sensor, controller, and LED load. This path is separate from the vehicle charging link.</p></article>
              </div>
            </div>
          </div>
        </section>

        <section className="section wrap experiments-section" id="experiments">
          <SectionHeading kicker="03 — Experimental plan" title="Four variables. One honest baseline." detail="A staged bench program turns a compelling concept into a question with an answer. Select a test to inspect its independent variable and planned observation." />
          <div className="experiment-layout">
            <div className="trial-list" role="tablist" aria-label="Planned experiment">
              {trials.map((trial) => (
                <button className={`trial-tab ${activeTrial === trial.id ? 'selected' : ''}`} type="button" key={trial.id} role="tab" aria-selected={activeTrial === trial.id} aria-controls="trial-panel" onClick={() => setActiveTrial(trial.id)} data-testid={`tab-trial-${trial.id}`}>
                  <span className="trial-num mono">{trial.number}</span><span className="trial-name">{trial.name}</span><ArrowUpRight size={15} className="trial-arrow" />
                </button>
              ))}
              <div className="plan-aside"><span className="mono">CONTROL FIRST</span><p>Lock down coil geometry, input conditions, load, and instrumentation before comparing trials.</p></div>
            </div>
            <div className="trial-detail" id="trial-panel" role="tabpanel" aria-live="polite">
              <div className="trial-detail-head"><span className={`trial-symbol ${selectedTrial.color}`}><CircuitBoard size={18} /></span><span className="mono">PROTOCOL {selectedTrial.number} / PLANNED</span><span className="illustrative-label">Illustrative setup</span></div>
              <h3>{selectedTrial.name}</h3>
              <p className="trial-sub">Vary <strong>{selectedTrial.variable}</strong> while holding the reference load and drive conditions as constant as practical.</p>
              <div className="trial-visual">
                <div className="visual-top"><span className="mono">PROPOSED SWEEP</span><span>NO DATA RECORDED</span></div>
                <div className="plot">
                  <div className="plot-y"><span>response</span><span>—</span><span>—</span><span>—</span></div>
                  <div className="plot-area">
                    <i className="plot-grid g1" /><i className="plot-grid g2" /><i className="plot-grid g3" />
                    <svg viewBox="0 0 500 130" preserveAspectRatio="none" role="img" aria-label="Illustrative blank plot showing a placeholder dotted path, not experimental data.">
                      <path d="M15 105 C80 90 100 76 155 72 S245 80 292 50 S390 43 485 27" fill="none" stroke="currentColor" strokeWidth="2" strokeDasharray="5 7" className={`plot-line ${selectedTrial.color}`} />
                      <text x="180" y="60" className="plot-watermark">ILLUSTRATIVE ONLY</text>
                    </svg>
                    <div className="plot-x"><span>{selectedTrial.range.split(' → ')[0]}</span><span>{selectedTrial.variable}</span><span>{selectedTrial.range.split(' → ')[1]}</span></div>
                  </div>
                </div>
                <div className="plot-legend"><i /> Placeholder curve for layout only. No measured points.</div>
              </div>
              <div className="trial-metrics">
                <div><span className="mono">OBSERVE</span><b>{selectedTrial.response}</b></div>
                <div><span className="mono">RECORD</span><b>Raw readings + conditions</b></div>
                <div><span className="mono">STATUS</span><b className="planned-status">Protocol in planning</b></div>
              </div>
            </div>
          </div>
          <div className="measurement-bar"><span className="measure-icon"><Check size={15} /></span><p><b>Minimum record for every run:</b> date, setup photo or diagram, coil dimensions, gap / offset, input voltage and current, received-side load, temperature, instrument model, repeat count, and deviations.</p><a href="#proof" className="focus-ring">Data release plan <ArrowRight size={14} /></a></div>
        </section>

        <section className="integrity-section" id="integrity">
          <div className="wrap integrity-grid">
            <div><p className="eyebrow">04 — Evidence, not theater</p><h2 className="display">Ambition needs<br />a boundary.</h2><p className="integrity-lede">No experimental measurements, validated efficiency, or completed hardware were supplied for this portfolio. The next honest step is not a big claim. It is a well-instrumented baseline.</p></div>
            <div className="claim-list">
              <div className="claim-row"><span className="claim-sign known">01</span><div><b>Known from the brief</b><p>The proposed architecture has two distinct energy paths and a four-part measurement plan.</p></div><span className="claim-state">STATED</span></div>
              <div className="claim-row"><span className="claim-sign hypothesis">02</span><div><b>Hypothesis to test</b><p>Dynamic transfer and auxiliary harvesting can coexist in a useful, measurable bench prototype.</p></div><span className="claim-state">UNVERIFIED</span></div>
              <div className="claim-row"><span className="claim-sign goal">03</span><div><b>Design goal, not outcome</b><p>Reduced vehicle charging burden or grid demand is a future system-level hypothesis, not an established impact.</p></div><span className="claim-state">NOT CLAIMED</span></div>
              <div className="claim-row"><span className="claim-sign limit">04</span><div><b>Physical scale matters</b><p>Mechanical harvesting is expected to support low-power electronics only; it is not a traction-energy source.</p></div><span className="claim-state">SCOPE LIMIT</span></div>
            </div>
          </div>
        </section>

        <section className="section wrap roadmap-section" id="roadmap">
          <SectionHeading kicker="05 — Development roadmap" title="Proof, one phase at a time." detail="Progress is defined by evidence artifacts—not by how finished a rendering looks. Planned phases remain planned until the work is documented." />
          <div className="roadmap">
            {roadmap.map((item) => <article className="roadmap-item" key={item.step}>
              <div className="roadmap-rail"><span>{item.step}</span><i /></div>
              <div className="roadmap-content"><div className="roadmap-meta"><span className="mono">{item.phase}</span><span className={`phase-state ${item.status === 'IN PROGRESS' ? 'active-phase' : ''}`}>{item.status}</span></div><h3>{item.title}</h3><p>{item.body}</p></div>
            </article>)}
          </div>
          <div className="roadmap-foot"><span className="mono">CURRENT PHASE</span><span className="roadmap-current"><i /> MODEL / CONCEPT SPECIFICATION</span><span>All implementation milestones are prospective.</span></div>
        </section>

        <section className="section wrap publication-section" id="publication">
          <SectionHeading kicker="06 — Prepared research materials" title="A draft, with the blank results left blank." detail="Both files are working documents. The manuscript proposes a model and a repeatable bench protocol; the demo labels what exists now versus what would require a built and instrumented prototype." />
          <div className="publication-grid">
            <article className="publication-card paper-card">
              <div className="publication-card-head">
                <span className="publication-icon"><FileText size={18} /></span>
                <span className="publication-status">IEEE-STYLE WORKING DRAFT</span>
              </div>
              <h3>Bench-scale system and test protocol</h3>
              <p>System model, coupled-coil equations, measurement boundaries, controlled test sequence, analysis plan, limitations, and results-to-be-collected placeholders.</p>
              <div className="publication-tags"><span>MODEL</span><span>METHODS</span><span>NO RESULTS CLAIMED</span></div>
              <a className="publication-link focus-ring" href={`${import.meta.env.BASE_URL}ahhi-paper-draft.md`} download>
                Download paper draft <ArrowUpRight size={14} />
              </a>
            </article>
            <article className="publication-card demo-card">
              <div className="publication-card-head">
                <span className="publication-icon demo-icon"><Timer size={18} /></span>
                <span className="publication-status demo-status">60 SECONDS · CONCEPT WALKTHROUGH</span>
              </div>
              <h3>Demo outline with an evidence boundary</h3>
              <p>A timed script for presenting the concept, model, and planned tests. It explicitly says this portfolio has no completed hardware or connected telemetry stream.</p>
              <div className="demo-timing" aria-label="Demo timing">
                <span>00–08 STATUS</span><span>08–28 MODEL</span><span>28–52 TEST PLAN</span><span>52–60 NEXT STEP</span>
              </div>
              <a className="publication-link focus-ring" href={`${import.meta.env.BASE_URL}ahhi-demo-outline.md`} download>
                Download demo outline <ArrowUpRight size={14} />
              </a>
            </article>
          </div>
          <p className="publication-note"><b>Evidence status:</b> the draft is not a final IEEE submission, and the demo is not a live hardware demonstration. Add results only after measurements are taken, documented, and checked.</p>
        </section>

        <section className="proof-section" id="proof">
          <div className="wrap proof-grid">
            <div className="proof-copy">
              <p className="eyebrow">07 — Open-source proof of work</p>
              <h2 className="display">Make the process<br />inspectable.</h2>
              <p>The repository is the product as much as the prototype: methods, assumptions, revisions, negative results, and raw data should travel together.</p>
              <div className="repo-placeholder"><GitBranch size={16} /><span><b>Repository link</b><small>Not supplied yet · no files are being represented as uploaded</small></span><span className="repo-status">TO BE ADDED</span></div>
              <a className="proof-cta focus-ring" href="#roadmap">See planned release phases <ArrowRight size={15} /></a>
            </div>
            <div className="proof-manifest">
              <div className="manifest-head"><span className="mono">INTENDED REPOSITORY / MANIFEST</span><span>PROPOSED</span></div>
              <div className="manifest-row"><span className="filetype">MD</span><div><b>README.md</b><small>Scope, safety notes, evidence status</small></div><span>01</span></div>
              <div className="manifest-row"><span className="filetype orange-file">PDF</span><div><b>methods/bench-protocol.pdf</b><small>Versioned procedure + run sheet</small></div><span>02</span></div>
              <div className="manifest-row"><span className="filetype blue-file">CSV</span><div><b>data/raw/</b><small>Timestamped measurements; no fabricated rows</small></div><span>03</span></div>
              <div className="manifest-row"><span className="filetype">IPYNB</span><div><b>analysis/</b><small>Plots and uncertainty calculations</small></div><span>04</span></div>
              <div className="manifest-row"><span className="filetype orange-file">SCH</span><div><b>hardware/schematics/</b><small>Revision history + bill of materials</small></div><span>05</span></div>
              <div className="manifest-foot"><span className="mono">PROPOSED STRUCTURE · NOT AN UPLOADED REPOSITORY</span><span><RotateCcw size={13} /> Reproducible by design</span></div>
            </div>
          </div>
        </section>

        <section className="section wrap activity-section" id="activity">
          <div className="activity-card">
            <div className="activity-left">
              <p className="eyebrow">08 — Application-ready summary</p>
              <p className="activity-title">DRAFT TITLE · LEAD INDEPENDENT RESEARCHER</p>
              <h2 className="display">A concise record<br />of work in progress.</h2>
              <p>A carefully bounded activity statement that describes intent and planned methods without implying results that do not exist.</p>
              <button className="copy-button focus-ring" onClick={copyActivity} type="button" data-testid="button-copy-summary">
                {copied ? <Check size={15} /> : <Copy size={15} />}{copied ? 'Copied summary' : 'Copy activity summary'}
              </button>
            </div>
            <div className="activity-quote">
              <span className="quote-mark">“</span>
              <p>{activity}</p>
              <div className="quote-foot"><span className="mono">ACTIVITY DESCRIPTION / DRAFT</span><span>Evidence status: planned work</span></div>
            </div>
          </div>
        </section>

        <section className="closing wrap">
          <div className="closing-mark"><BatteryCharging size={21} /></div>
          <div><p className="eyebrow">A prototype begins with a question.</p><h2 className="display">What can the road<br /><em>actually</em> give back?</h2></div>
          <a href="#top" className="back-top focus-ring" aria-label="Back to top">Back to top <ArrowUpRight size={15} /></a>
        </section>
      </main>

      <footer className="footer">
        <div className="wrap footer-inner">
          <a className="wordmark footer-brand" href="#top"><span className="mark">A<span>H</span></span><span className="brand-copy"><b>AHHI</b><small>RESEARCH PORTFOLIO</small></span></a>
          <p>Student-led · concept-stage · evidence-first</p>
          <span className="mono">© AHHI / RESEARCH NOTES 01</span>
        </div>
      </footer>
    </div>
  );
}

export default App;
