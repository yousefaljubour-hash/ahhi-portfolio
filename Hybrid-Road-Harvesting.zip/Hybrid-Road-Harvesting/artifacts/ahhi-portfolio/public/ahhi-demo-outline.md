# AHHI 60-Second Demo Outline

**Format:** Concept-and-protocol walkthrough in the existing AHHI portfolio  
**Current hardware status:** No completed AHHI hardware prototype is available in this project.  
**Current telemetry status:** No live telemetry source is connected. Do not describe the illustrations or blank experiment plots as live readings.

## Timed outline and spoken script

| Time | Show | Script |
|---|---|---|
| 0–8 sec | Portfolio opening and the “PRE-EXPERIMENTAL” status | “This is the AHHI research concept. In this build, there is no completed hardware prototype and no connected live telemetry.” |
| 8–18 sec | System diagram: transmitter, air gap, receiver, separate auxiliary path | “The proposal has two separate paths: an inductive link for the main power-transfer study, and a vibration harvester intended only for low-power sensing or control.” |
| 18–28 sec | Idealized coupling equation, *M = k√(L₁L₂)* | “This equation is a first-order model. The coupling for this coil geometry is unknown; the model does not predict a measured result.” |
| 28–40 sec | Planned experiments: gap, offset, temperature, vibration | “These are planned bench tests, not completed runs. Each needs a fixed reference, repeated measurements, and recorded instrument limits.” |
| 40–52 sec | Blank/illustrative experiment panel and this evidence boundary | “There is no data stream to show today. The plotted placeholder is labeled illustrative, and the results sections are intentionally empty. A future telemetry view must be fed by a real, identified instrument or sensor.” |
| 52–60 sec | Close on the next research step | “The next step is a safe, instrumented baseline. Any performance claim comes after the measurements, uncertainty, and repeatability are documented.” |

**Total runtime: 60 seconds.** Keep the pace conversational; if the interface takes longer to navigate, reduce the time spent on the equation rather than skipping the hardware and telemetry disclosure.

## If a real telemetry stream is added later

Replace the no-stream statement only after an actual instrumented bench setup is operating. Identify the physical source, sensor or instrument, units, sample interval, and timestamp on screen. Show raw readings or a clearly labeled measured view; retain the setup and test-condition identifiers. Do not fill gaps with generated values, replayed examples, interpolated traces, or simulation output presented as live data. If the stream disconnects, display that it is disconnected rather than holding old values as current.

For a future recording, distinguish measured readings from derived quantities (for example, calculated power), and state the measurement boundary. A live number without its source, unit, operating condition, and uncertainty is not a validated result.
